<?php

// base de datos
$db = new DB("127.0.0.1", "Template", "root","");


 ?>

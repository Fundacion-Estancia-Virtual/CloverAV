<?php
error_reporting(0);
define('HOST', 'http://localhost:5000/');
// base de datos
$db = new DB("213.190.6.106","u811232073_cloverav","u811232073_cloverav","*Z&Zj4n]5c");


 ?>

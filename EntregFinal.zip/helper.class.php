<?php
/**
 * Funciones auxilares
 */
class Helper{
    function __construct() {
    }
    public function suma($a, $b){
        return $a + $b;
    }
}

 ?>

<?php
/**
 *
 */
class Lib{
    function __construct(){
        // code...
    }
    public function hello(){
        return "HOLA MUNDO";
    }
}


 ?>
